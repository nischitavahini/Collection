# NischitaVahini_Collections
EPAM home task on Collections
